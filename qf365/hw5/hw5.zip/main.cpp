#include <iostream>
#include <string>
#include "StockStat.h"
#include "StockStat.cpp"
using namespace std;

int main(){
    StockStat myStat;
    myStat.run();
    return 0;
}
