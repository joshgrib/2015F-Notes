#include <iostream>
#include <string>
#include "Queens.h"
#include "Queens.cpp"
using namespace std;

#define N 6

int main(){
    Queens myQ(6);
    return 0;
}
